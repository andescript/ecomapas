<!DOCTYPE html>
<!--
       .o                                8888       8888
      .88                                8888       8888
    o8888oo  ooo  oooo  ooo. .oo.  .oo.   888oooo.   888  oooo d8b
    ""888""  888  "888  "888P"Y88bP"Y88b  d88' `88b  888  "888""8P
      888    888   888   888   888   888  888   888  888   888
      888 .  888   888   888   888   888  888.  888  888   888
      "888Y  `V88V"V8P' o888o o888o o888o 88`bod8P' o888o d888b

                                                                        -->
<!--[if lt IE 9]><html class="ie"><![endif]-->
<!--[if IE 9]><html class="ie9"><![endif]-->
<!--[if gt IE 9]><!--><html><!--<![endif]-->
    <head>
        <title>Not found.</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta http-equiv="x-dns-prefetch-control" content="off">
        <meta name="robots" content="noindex">
        <meta name="viewport" content="width=device-width">
        <meta name="msapplication-TileImage" content="//assets.tumblr.com/images/msfavicon.png?_v=245323c5cb69e705ea213d9ed60e543a">
        <meta http-equiv="refresh" content="3;url=https://www.tumblr.com/explore?referer=404">        <link rel="shortcut icon" href="//assets.tumblr.com/images/favicons/favicon.ico?_v=8bfa6dd3e1249cd567350c606f8574dc">
        <link rel="stylesheet" media="screen" href="//assets.tumblr.com/client/prod/standalone/error-pages/index.build.css?_v=da302762836d5bf2aeee0f6522476e59">
    </head>
    <body class="has-background-image" data-status-code="404">

        <div class="fullscreen-background" data-js-fullscreen-background></div>

        <div class="error-message-container">
            <div class="error-message-content">
                <h1 class="error-message-title" data-localization="heading">
                    There's nothing here.
                </h1>

                <p class="error-message-text" data-localization="message">
                    Whatever you were looking for doesn't currently exist at this address. Unless you were looking for this error page, in which case: Congrats! You totally found it.
                </p>

                <div class="logged-out-buttons" data-js-logged-out-buttons>
                    <a class="tx-button gray" href="https://www.tumblr.com/login" data-localization="log_in">Log in</a>
                    <a class="tx-button blue" href="https://www.tumblr.com/register" data-localization="sign_up">Sign up</a>
                </div>
            </div>
        </div>

        <div class="l-header-container">
            <div class="l-header">
                <h1 class="logo">
                    <a tabindex="-1" class="logo-anchor" target="_blank" href="https://www.tumblr.com" aria-label="Tumblr">
                        <div class="png-logo"></div>
                    </a>
                </h1>

                <form class="search-field-form" method="get" action="//www.tumblr.com/search" role="search">
                    <input type="hidden" name="referring_page" value="404">
                    <input type="hidden" name="scope" value="all_of_tumblr">
                    <div class="search-field-box" class="search_form_row">
                        <input class="search-field-input" tabindex="1" type="text" name="q" placeholder="Search Tumblr" value="" autocomplete="off" data-localization="search_tags" data-js-search-field>
                        <button class="search-field-button" type="submit" data-localization="search">Search</button>
                    </div>
                </form>

                <div class="logged-out-buttons" data-js-logged-out-buttons>
                    <a class="tx-button gray" href="https://www.tumblr.com/login" data-localization="log_in">Log in</a>
                    <a class="tx-button blue" href="https://www.tumblr.com/register" data-localization="sign_up">Sign up</a>
                </div>
            </div>
        </div>

        <div class="error-message-post-attribution" data-js-post-attribution></div>

        <script src="//assets.tumblr.com/languages/errors.js?_v=aa8ebc5ca20b127a3a667152c15432a2"></script>
        <script src="//assets.tumblr.com/client/prod/standalone/error-pages/index.build.js?_v=f7b55c2ded2a9d2552e4508af77a98a4"></script>

    </body>
</html>
